/**
 * Stock Research Dashboard — Cloudflare Worker
 *
 * Endpoints (all CORS-enabled):
 *   GET  /api/quote/:ticker             -> Yahoo quoteSummary (fundamentals, calendar, recs, profile)
 *   GET  /api/chart/:ticker?range&intvl -> Yahoo chart (OHLCV)
 *   GET  /api/options/:ticker[?date]    -> Yahoo options chain
 *   GET  /api/search?q=                 -> Yahoo ticker search
 *   GET  /api/news/:ticker              -> Yahoo news feed
 *   GET  /api/peers/:ticker             -> Yahoo recommendationsBySymbol
 *   POST /api/claude                    -> Anthropic Messages API proxy (sentiment, synthesis)
 *   POST /api/log-rec                   -> Append a rating snapshot to KV (forward log)
 *   GET  /api/track/:ticker             -> Read past rating snapshots from KV
 *
 * Required bindings:
 *   ANTHROPIC_API_KEY (secret) — Anthropic API key
 *   REC_LOG (KV namespace)     — forward log for recommendations
 *
 * Model identifier locked to `claude-sonnet-4-5` (the dated variant returns auth errors).
 */

const ALLOWED_ORIGINS = ['*']; // Tighten to your gh-pages origin in prod.
const CLAUDE_MODEL = 'claude-sonnet-4-5';
const YAHOO_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
  'Accept': 'application/json,text/plain,*/*',
};

const cors = (extra = {}) => ({
  'Access-Control-Allow-Origin': ALLOWED_ORIGINS[0],
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Max-Age': '86400',
  ...extra,
});

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...cors() },
  });

const err = (msg, status = 500) => json({ error: msg }, status);

async function yahoo(path, search = '') {
  const url = `https://query2.finance.yahoo.com${path}${search}`;
  const r = await fetch(url, { headers: YAHOO_HEADERS, cf: { cacheTtl: 30, cacheEverything: true } });
  if (!r.ok) throw new Error(`Yahoo ${r.status}`);
  return r.json();
}

async function handleQuote(ticker) {
  const modules = [
    'price', 'summaryDetail', 'defaultKeyStatistics', 'financialData',
    'calendarEvents', 'recommendationTrend', 'upgradeDowngradeHistory',
    'earningsHistory', 'earningsTrend', 'assetProfile',
    'institutionOwnership', 'majorHoldersBreakdown', 'insiderTransactions',
    'insiderHolders', 'netSharePurchaseActivity',
  ].join(',');
  const data = await yahoo(`/v10/finance/quoteSummary/${ticker}`, `?modules=${modules}`);
  return json(data);
}

async function handleChart(ticker, params) {
  const range = params.get('range') || '1y';
  const interval = params.get('interval') || '1d';
  const data = await yahoo(`/v8/finance/chart/${ticker}`, `?range=${range}&interval=${interval}&includePrePost=false`);
  return json(data);
}

async function handleOptions(ticker, params) {
  const date = params.get('date');
  const search = date ? `?date=${date}` : '';
  const data = await yahoo(`/v7/finance/options/${ticker}`, search);
  return json(data);
}

async function handleSearch(q) {
  const r = await fetch(
    `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=8&newsCount=0`,
    { headers: YAHOO_HEADERS }
  );
  return json(await r.json());
}

async function handleNews(ticker) {
  // Yahoo's news endpoint via search
  const r = await fetch(
    `https://query2.finance.yahoo.com/v1/finance/search?q=${ticker}&quotesCount=0&newsCount=15`,
    { headers: YAHOO_HEADERS }
  );
  return json(await r.json());
}

async function handlePeers(ticker) {
  const data = await yahoo(`/v6/finance/recommendationsbysymbol/${ticker}`);
  return json(data);
}

async function handleClaude(request, env) {
  if (!env.ANTHROPIC_API_KEY) return err('ANTHROPIC_API_KEY not configured', 500);
  const body = await request.json();

  const payload = {
    model: CLAUDE_MODEL,
    max_tokens: body.max_tokens ?? 1500,
    messages: body.messages,
    ...(body.system ? { system: body.system } : {}),
  };

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(payload),
  });
  const data = await r.json();
  return json(data, r.status);
}

async function handleLogRec(request, env) {
  if (!env.REC_LOG) return err('REC_LOG KV not bound', 500);
  const body = await request.json();
  const { ticker, rating, confidence, price, factors } = body;
  if (!ticker || !rating) return err('ticker and rating required', 400);

  const entry = {
    ticker: ticker.toUpperCase(),
    rating,
    confidence: confidence ?? null,
    price: price ?? null,
    factors: factors ?? {},
    ts: new Date().toISOString(),
  };
  // List key per ticker; append-only
  const key = `rec:${entry.ticker}`;
  const existing = await env.REC_LOG.get(key, 'json');
  const list = Array.isArray(existing) ? existing : [];
  list.push(entry);
  // Keep last 500 per ticker
  await env.REC_LOG.put(key, JSON.stringify(list.slice(-500)));
  return json({ ok: true, count: list.length });
}

async function handleTrack(ticker, env) {
  if (!env.REC_LOG) return err('REC_LOG KV not bound', 500);
  const list = (await env.REC_LOG.get(`rec:${ticker.toUpperCase()}`, 'json')) || [];
  return json({ ticker: ticker.toUpperCase(), entries: list });
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors() });

    const url = new URL(request.url);
    const parts = url.pathname.split('/').filter(Boolean); // ['api', 'quote', 'AAPL']

    if (parts[0] !== 'api') return err('not found', 404);

    try {
      const [, route, ticker] = parts;
      switch (route) {
        case 'quote':   return await handleQuote(ticker);
        case 'chart':   return await handleChart(ticker, url.searchParams);
        case 'options': return await handleOptions(ticker, url.searchParams);
        case 'search':  return await handleSearch(url.searchParams.get('q') || '');
        case 'news':    return await handleNews(ticker);
        case 'peers':   return await handlePeers(ticker);
        case 'claude':  return await handleClaude(request, env);
        case 'log-rec': return await handleLogRec(request, env);
        case 'track':   return await handleTrack(ticker, env);
        default:        return err('unknown route', 404);
      }
    } catch (e) {
      return err(e.message, 500);
    }
  },
};
